import Cocoa
import Combine

class WorkspaceObserver: ObservableObject {
    @Published private(set) var isFullScreenAppActive: Bool = false
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        let wsNC = NSWorkspace.shared.notificationCenter
        
        // Listen to Active Space and App Activation changes
        Publishers.Merge3(
            wsNC.publisher(for: NSWorkspace.activeSpaceDidChangeNotification),
            wsNC.publisher(for: NSWorkspace.didActivateApplicationNotification),
            wsNC.publisher(for: NSWorkspace.didDeactivateApplicationNotification)
        )
        .receive(on: RunLoop.main)
        .sink { [weak self] _ in
            self?.checkFullScreenState()
        }
        .store(in: &cancellables)
        
        // Initial check
        checkFullScreenState()
    }
    
    /// Queries current window bounds across screens to see if any full-screen app window is present
    func checkFullScreenState() {
        guard let windowList = CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID) as? [[String: Any]] else {
            return
        }
        
        let screenFrames = NSScreen.screens.map { $0.frame }
        var detectedFullScreen = false
        
        for window in windowList {
            // Ignore windows belonging to YoWall
            if let ownerPID = window[kCGWindowOwnerPID as String] as? pid_t,
               ownerPID == ProcessInfo.processInfo.processIdentifier {
                continue
            }
            
            // Check window layer (0 is normal application window layer)
            if let layer = window[kCGWindowLayer as String] as? Int, layer == 0,
               let boundsDict = window[kCGWindowBounds as String] as? [String: CGFloat],
               let windowBounds = CGRect(dictionaryRepresentation: boundsDict as CFDictionary) {
                
                // Compare against connected screens
                for screenFrame in screenFrames {
                    let isWidthMatching = abs(windowBounds.width - screenFrame.width) < 5
                    let isHeightMatching = abs(windowBounds.height - screenFrame.height) < 5
                    
                    if isWidthMatching && isHeightMatching {
                        detectedFullScreen = true
                        break
                    }
                }
            }
            if detectedFullScreen { break }
        }
        
        if self.isFullScreenAppActive != detectedFullScreen {
            self.isFullScreenAppActive = detectedFullScreen
            print("Workspace state updated - Full Screen Active: \(detectedFullScreen)")
        }
    }
}
