import Foundation
import Combine
import SwiftUI
import AVFoundation

class WallpaperManager: ObservableObject {
    @Published var wallpapers: [WallpaperItem] = []
    @Published var activeWallpaper: WallpaperItem?
    @Published var isManuallyPaused: Bool = false
    @Published var placement: WallpaperPlacement = .both
    
    var getCurrentTime: (() -> Double?)? = nil
    
    private let saveKey = "YoWall_SavedWallpapers"
    private let activeKey = "YoWall_ActiveWallpaperID"
    private var cancellables = Set<AnyCancellable>()

    init() {
        loadWallpapers()
        loadPlacement()
        observePlacementChanges()
        observeScreenLock()
        observeScreenUnlock()
        
        // Ensure correct wallpaper state on app launch
        updateSystemWallpaperState(isLocked: false)
    }
    
    // MARK: - State Router
    
    func updateSystemWallpaperState(isLocked: Bool) {
        // 1. Handle Desktop Video Window Visibility
        // Hide the video window entirely if it's set to Lock Screen Only, or if no wallpaper exists
        let shouldShowVideo = (placement == .home || placement == .both) && (activeWallpaper != nil) && !wallpapers.isEmpty
        
        DispatchQueue.main.async {
            for window in NSApplication.shared.windows {
                // Target the background video window (which lives behind normal UI windows like Settings)
                if window.level < .normal {
                    window.alphaValue = shouldShowVideo ? 1.0 : 0.0
                }
            }
        }

        // 2. If no wallpapers exist, MUST revert to original system wallpaper
        if activeWallpaper == nil || wallpapers.isEmpty {
            LockScreenManager.shared.restoreOriginalWallpapers()
            return
        }

        // 3. Dynamic swapping based on placement intent
        switch placement {
        case .home:
            // Lock screen untouched, always restore original
            LockScreenManager.shared.restoreOriginalWallpapers()
            
        case .lock:
            if isLocked {
                // Apply the video freeze-frame ONLY while locked
                syncLockScreen(useCurrentTime: true)
            } else {
                // Instantly restore their normal desktop when unlocked
                LockScreenManager.shared.restoreOriginalWallpapers()
            }
            
        case .both:
            // Always sync the frame behind the video player
            syncLockScreen(useCurrentTime: isLocked)
        }
    }
    
    private func syncLockScreen(useCurrentTime: Bool = false) {
        guard let active = activeWallpaper,
              let resolved = resolveURL(for: active) else { return }
        
        let currentTimeInSeconds = useCurrentTime ? getCurrentTime?() : nil
        
        Task {
            do {
                try await LockScreenManager.shared.applyLockScreenWallpaper(from: resolved.url, at: currentTimeInSeconds)
            } catch {
                print("[YoWall] Failed to sync Lock Screen: \(error.localizedDescription)")
            }
        }
    }
    
    // MARK: - Placement Management
    
    private func loadPlacement() {
        if let savedPlacement = UserDefaults.standard.string(forKey: "YoWall_Placement"),
           let parsed = WallpaperPlacement(rawValue: savedPlacement) {
            self.placement = parsed
        }
    }

    private func observePlacementChanges() {
        NotificationCenter.default.publisher(for: UserDefaults.didChangeNotification)
            .compactMap { _ in UserDefaults.standard.string(forKey: "YoWall_Placement") }
            .compactMap { WallpaperPlacement(rawValue: $0) }
            .removeDuplicates()
            .receive(on: RunLoop.main)
            .sink { [weak self] newPlacement in
                self?.placement = newPlacement
                self?.updateSystemWallpaperState(isLocked: false)
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Lock & Unlock Screen Observers
    
    private func observeScreenLock() {
        DistributedNotificationCenter.default().addObserver(
            forName: Notification.Name("com.apple.screenIsLocked"),
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.updateSystemWallpaperState(isLocked: true)
        }
    }
    
    private func observeScreenUnlock() {
        DistributedNotificationCenter.default().addObserver(
            forName: Notification.Name("com.apple.screenIsUnlocked"),
            object: nil,
            queue: .main
        ) { [weak self] _ in
            guard let self = self else { return }
            
            let shouldChangeOnUnlock = UserDefaults.standard.bool(forKey: "YoWall_ChangeOnUnlock")
            if shouldChangeOnUnlock && self.wallpapers.count > 1 {
                self.skipNext()
            } else {
                self.updateSystemWallpaperState(isLocked: false)
            }
        }
    }

    // MARK: - Wallpaper Actions

    func setActiveWallpaper(_ item: WallpaperItem) {
        activeWallpaper = item
        UserDefaults.standard.set(item.id.uuidString, forKey: activeKey)
        updateSystemWallpaperState(isLocked: false)
    }

    func deleteWallpaper(_ item: WallpaperItem) {
        wallpapers.removeAll { $0.id == item.id }
        if activeWallpaper?.id == item.id {
            activeWallpaper = wallpapers.first
            if let newActive = activeWallpaper {
                setActiveWallpaper(newActive)
            } else {
                UserDefaults.standard.removeObject(forKey: activeKey)
                // Instantly revert to original if they delete the last active wallpaper
                updateSystemWallpaperState(isLocked: false)
            }
        }
        saveWallpapers()
    }

    func skipNext() {
        guard !wallpapers.isEmpty else { return }
        guard let active = activeWallpaper, let currentIndex = wallpapers.firstIndex(of: active) else {
            if let first = wallpapers.first { setActiveWallpaper(first) }
            return
        }
        let nextIndex = (currentIndex + 1) % wallpapers.count
        setActiveWallpaper(wallpapers[nextIndex])
    }
    
    func skipPrevious() {
        guard !wallpapers.isEmpty else { return }
        guard let active = activeWallpaper, let currentIndex = wallpapers.firstIndex(of: active) else {
            if let first = wallpapers.first { setActiveWallpaper(first) }
            return
        }
        let prevIndex = currentIndex == 0 ? wallpapers.count - 1 : currentIndex - 1
        setActiveWallpaper(wallpapers[prevIndex])
    }

    func addWallpaper(from url: URL, customName: String? = nil) {
        guard url.startAccessingSecurityScopedResource() else { return }
        defer { url.stopAccessingSecurityScopedResource() }
        
        do {
            let bookmarkData = try url.bookmarkData(
                options: .withSecurityScope,
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            
            let fileExtension = url.pathExtension.lowercased()
            let type: WallpaperType = fileExtension == "gif" ? .gif : .video
            let displayName = (customName?.isEmpty == false) ? customName! : url.deletingPathExtension().lastPathComponent
            
            let newItem = WallpaperItem(name: displayName, bookmarkData: bookmarkData, type: type)
            
            wallpapers.append(newItem)
            saveWallpapers()
            
            if activeWallpaper == nil { setActiveWallpaper(newItem) }
        } catch {
            print("Failed to create bookmark: \(error)")
        }
    }

    func resolveURL(for item: WallpaperItem) -> (url: URL, isAccessing: Bool)? {
        var isStale = false
        do {
            let resolvedURL = try URL(resolvingBookmarkData: item.bookmarkData, options: .withSecurityScope, relativeTo: nil, bookmarkDataIsStale: &isStale)
            let isAccessing = resolvedURL.startAccessingSecurityScopedResource()
            return (resolvedURL, isAccessing)
        } catch {
            print("Error resolving bookmark: \(error)")
            return nil
        }
    }

    func validateDiskExistence() {}

    func saveWallpapers() {
        if let encoded = try? JSONEncoder().encode(wallpapers) {
            UserDefaults.standard.set(encoded, forKey: saveKey)
        }
    }

    private func loadWallpapers() {
        if let data = UserDefaults.standard.data(forKey: saveKey),
           let decoded = try? JSONDecoder().decode([WallpaperItem].self, from: data) {
            self.wallpapers = decoded
        }
        
        if let activeIDString = UserDefaults.standard.string(forKey: activeKey),
           let uuid = UUID(uuidString: activeIDString) {
            self.activeWallpaper = wallpapers.first(where: { $0.id == uuid })
        } else {
            self.activeWallpaper = wallpapers.first
        }
    }
}
