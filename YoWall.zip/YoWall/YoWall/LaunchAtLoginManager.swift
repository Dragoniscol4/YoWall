import Foundation
import Combine
import ServiceManagement

class LaunchAtLoginManager: ObservableObject {
    @Published var isEnabled: Bool = false
    
    init() {
        checkState()
    }
    
    func checkState() {
        if #available(macOS 13.0, *) {
            isEnabled = SMAppService.mainApp.status == .enabled
        } else {
            isEnabled = UserDefaults.standard.bool(forKey: "LaunchAtLoginLegacy")
        }
    }
    
    func toggle(to state: Bool) {
        if #available(macOS 13.0, *) {
            do {
                if state {
                    try SMAppService.mainApp.register()
                } else {
                    try SMAppService.mainApp.unregister()
                }
                isEnabled = state
            } catch {
                print("Failed to toggle launch at login: \(error)")
            }
        } else {
            let helperBundleId = "com.yourdomain.YoWallHelper" as CFString
            SMLoginItemSetEnabled(helperBundleId, state)
            UserDefaults.standard.set(state, forKey: "LaunchAtLoginLegacy")
            isEnabled = state
        }
    }
}
