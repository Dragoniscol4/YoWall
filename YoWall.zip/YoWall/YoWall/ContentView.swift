import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject var manager: WallpaperManager
    
    let columns = [
        GridItem(.adaptive(minimum: 160, maximum: 220), spacing: 16)
    ]
    
    var body: some View {
        ZStack(alignment: .bottom) {
            Color.clear
            
            VStack(spacing: 20) {
                // Top Header Row
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("YoWall")
                            .font(.system(size: 28, weight: .bold))
                        Text("Animated Desktop Engine")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    Spacer()
                    
                    // NEW: Settings Button
                    if #available(macOS 13.0, *) {
                        SettingsLink {
                            Image(systemName: "gearshape.fill")
                                .font(.title2)
                                .foregroundColor(.secondary)
                        }
                        .buttonStyle(.plain)
                        .padding(.trailing, 8)
                    } else {
                        Button(action: {
                            NSApp.sendAction(Selector(("showSettingsWindow:")), to: nil, from: nil)
                        }) {
                            Image(systemName: "gearshape.fill")
                                .font(.title2)
                                .foregroundColor(.secondary)
                        }
                        .buttonStyle(.plain)
                        .padding(.trailing, 8)
                    }
                    
                    Button(action: selectFile) {
                        Label("Add Animated Wallpaper", systemImage: "plus.circle.fill")
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(.horizontal, 24)
                .padding(.top, 24)
                
                if manager.wallpapers.isEmpty {
                    VStack(spacing: 12) {
                        Spacer()
                        Image(systemName: "video.badge.plus")
                            .font(.system(size: 48))
                            .foregroundColor(.secondary)
                        Text("No Wallpapers Added")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        Text("Click 'Add Animated Wallpaper' to import a video or GIF.")
                            .font(.subheadline)
                            .foregroundColor(.secondary.opacity(0.8))
                        Spacer()
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(.bottom, 90)
                } else {
                    ScrollView {
                        LazyVGrid(columns: columns, spacing: 16) {
                            ForEach(manager.wallpapers) { item in
                                WallpaperCardView(item: item)
                            }
                        }
                        .padding(.horizontal, 24)
                        .padding(.bottom, 100)
                    }
                }
            }
            
            FloatingMiniplayerView()
                .padding(.horizontal, 24)
                .padding(.bottom, 20)
        }
        .frame(minWidth: 700, minHeight: 480)
        .liquidGlassBackground()
    }
    
    private func selectFile() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.canCreateDirectories = false
        panel.allowedContentTypes = [.movie, .gif, .quickTimeMovie]
        
        if panel.runModal() == .OK, let url = panel.url {
            manager.addWallpaper(from: url)
        }
    }
}

// MARK: - Wallpaper Card Component (With Renaming Fix)
struct WallpaperCardView: View {
    @EnvironmentObject var manager: WallpaperManager
    let item: WallpaperItem
    
    @State private var isEditingName = false
    @State private var editableName: String = ""
    
    var isActive: Bool {
        manager.activeWallpaper?.id == item.id
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: item.type == .gif ? "photo.on.rectangle.angled" : "video.fill")
                    .foregroundColor(.secondary)
                Spacer()
                if isActive {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.green)
                }
            }
            
            // NEW: Inline Renaming Logic
            if isEditingName {
                TextField("Wallpaper Name", text: $editableName, onCommit: {
                    saveName()
                })
                .textFieldStyle(.roundedBorder)
                .onAppear { editableName = item.name }
            } else {
                Text(item.name)
                    .font(.system(size: 14, weight: .semibold))
                    .lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .onTapGesture(count: 2) {
                        editableName = item.name
                        isEditingName = true
                    }
                    .help("Double-click to rename")
            }
            
            Spacer(minLength: 0)
            
            HStack {
                Button(action: {
                    manager.setActiveWallpaper(item)
                }) {
                    Text(isActive ? "Active" : "Apply")
                        .font(.caption)
                        .fontWeight(.bold)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(isActive ? Color.green.opacity(0.2) : Color.accentColor.opacity(0.2))
                        .foregroundColor(isActive ? .green : .accentColor)
                        .cornerRadius(6)
                }
                .buttonStyle(.plain)
                
                Spacer()
                
                Button(action: {
                    manager.deleteWallpaper(item)
                }) {
                    Image(systemName: "trash")
                        .font(.caption)
                        .foregroundColor(.red.opacity(0.8))
                        .padding(6)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(6)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(14)
        .frame(height: 130)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(isActive ? Color.accentColor.opacity(0.1) : Color.white.opacity(0.05))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(isActive ? Color.accentColor : Color.white.opacity(0.1), lineWidth: isActive ? 2 : 1)
        )
    }
    
    private func saveName() {
        guard !editableName.trimmingCharacters(in: .whitespaces).isEmpty else {
            isEditingName = false
            return
        }
        // Assuming your WallpaperManager can update items.
        // If it can't, you may need a small function in Manager to update the item's name!
        if let index = manager.wallpapers.firstIndex(where: { $0.id == item.id }) {
            manager.wallpapers[index].name = editableName
            manager.saveWallpapers() // Make sure you have this to persist changes
        }
        isEditingName = false
    }
}
