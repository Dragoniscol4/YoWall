import Cocoa
import SwiftUI

class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
    let wallpaperManager = WallpaperManager()
    let windowManager = WindowManager()
    let powerObserver = PowerObserver()
    let workspaceObserver = WorkspaceObserver()
    
    var statusItem: NSStatusItem?
    var popover: NSPopover?
    var clickMonitor: Any?
    var keyboardMonitor: Any?
    
    func applicationDidFinishLaunching(_ notification: Notification) {
        wallpaperManager.validateDiskExistence()
        
        // 1. Setup background desktop rendering windows
        windowManager.setupDesktopWindows {
            DesktopBackgroundView()
                .environmentObject(self.wallpaperManager)
                .environmentObject(self.powerObserver)
                .environmentObject(self.workspaceObserver)
        }
        
        // 2. Observe MenuBar preference
        UserDefaults.standard.register(defaults: ["YoWall_ShowMenuBarItem": true])
        UserDefaults.standard.addObserver(self, forKeyPath: "YoWall_ShowMenuBarItem", options: [.initial, .new], context: nil)
        
        // 3. Attach window delegate to the main window as soon as it opens
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleWindowDidBecomeKey(_:)),
            name: NSWindow.didBecomeKeyNotification,
            object: nil
        )
    }
    
    // FIX: Moved applicationShouldTerminate OUT of applicationDidFinishLaunching
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        // 1. Instantly restore the system background on all screens
        LockScreenManager.shared.restoreOriginalWallpapers()
        
        // 2. Clear out the cached image files to keep the user's drive clean
        LockScreenManager.shared.clearCache()
        
        // 3. Give macOS exactly 0.2 seconds to process the wallpaper change before we kill the app
        Thread.sleep(forTimeInterval: 0.2)
        
        // 4. Safely exit
        return .terminateNow
    }
    
    // Assign delegate to any normal UI window so we can intercept the Close button
    @objc private func handleWindowDidBecomeKey(_ notification: Notification) {
        guard let window = notification.object as? NSWindow else { return }
        if window.level == .normal &&
            !window.className.contains("Popover") &&
            window.title != "Settings" &&
            window.title != "General" {
            window.delegate = self
        }
    }
    
    // MARK: - Intercept Close Button (Hide Instead of Destroy)
    
    func windowShouldClose(_ sender: NSWindow) -> Bool {
        if sender.level == .normal && sender.title != "Settings" && sender.title != "General" {
            sender.orderOut(nil)
            return false
        }
        return true
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "YoWall_ShowMenuBarItem" {
            let show = UserDefaults.standard.bool(forKey: "YoWall_ShowMenuBarItem")
            DispatchQueue.main.async {
                if show { self.setupMenuBar() } else { self.removeMenuBar() }
            }
        }
    }
    
    private func removeMenuBar() {
        if let statusItem = statusItem {
            NSStatusBar.system.removeStatusItem(statusItem)
            self.statusItem = nil
        }
    }
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return false
    }
    
    // MARK: - Dock & MenuBar Window Toggle
    
    @objc func openMainWindow() {
        NSApp.activate(ignoringOtherApps: true)
        
        if let mainWindow = NSApp.windows.first(where: {
            $0.level == .normal &&
            !$0.className.contains("Popover") &&
            $0.title != "Settings" &&
            $0.title != "General"
        }) {
            if mainWindow.isMiniaturized {
                mainWindow.deminiaturize(nil)
            }
            mainWindow.makeKeyAndOrderFront(nil)
        }
    }
    
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        openMainWindow()
        return false
    }
    
    // MARK: - Menu Bar Setup
    
    private func setupMenuBar() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        
        if let button = statusItem?.button {
            // Safely try loading the custom image via asset catalog or bundle resource path
            let customImage = NSImage(named: "YoWall_Icon-removebg-preview copy 3.png") ??
                              NSImage(named: "YoWall_Icon-removebg-preview copy 3") ??
                              NSImage(contentsOfFile: Bundle.main.path(forResource: "YoWall_Icon-removebg-preview copy 3", ofType: "png") ?? "")
            
            if let icon = customImage {
                icon.size = NSSize(width: 18, height: 18)
                icon.isTemplate = true // Adapts automatically to light/dark mode
                button.image = icon
            } else {
                // Fallback safety: Uses standard system symbol if asset lookup fails entirely
                button.image = NSImage(systemSymbolName: "play.display", accessibilityDescription: "YoWall")
            }
            
            button.action = #selector(togglePopover)
        }
        
        popover = NSPopover()
        popover?.contentSize = NSSize(width: 260, height: 180)
        popover?.behavior = .transient
        popover?.contentViewController = NSHostingController(
            rootView: MenuBarView().environmentObject(wallpaperManager)
        )
    }

    @objc func togglePopover(_ sender: AnyObject?) {
        guard let currentPopover = popover else { return }
        
        if currentPopover.isShown {
            closePopover(sender)
        } else {
            showPopover(sender)
        }
    }

    func showPopover(_ sender: AnyObject?) {
        guard let currentPopover = popover, let button = statusItem?.button else { return }
        
        currentPopover.behavior = .applicationDefined
        
        NSApp.activate(ignoringOtherApps: true)
        currentPopover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
        
        if let window = currentPopover.contentViewController?.view.window {
            window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
            window.level = .floating
            window.makeKey()
        }
        
        clickMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown]) { [weak self] _ in
            self?.closePopover(nil)
        }
        
        keyboardMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { event in
            if event.modifierFlags.contains(.command) && event.charactersIgnoringModifiers?.lowercased() == "q" {
                NSApplication.shared.terminate(nil)
                return nil
            }
            return event
        }
    }

    func closePopover(_ sender: Any?) {
        popover?.performClose(sender)
        
        if let cMonitor = clickMonitor {
            NSEvent.removeMonitor(cMonitor)
            clickMonitor = nil
        }
        if let kMonitor = keyboardMonitor {
            NSEvent.removeMonitor(kMonitor)
            keyboardMonitor = nil
        }
    }
    
    // MARK: - Desktop Background Renderer
    
    struct DesktopBackgroundView: View {
        @EnvironmentObject var wallpaperManager: WallpaperManager
        @EnvironmentObject var powerObserver: PowerObserver
        @EnvironmentObject var workspaceObserver: WorkspaceObserver
        
        @AppStorage("YoWall_MuteAudio") private var isMuted: Bool = true
        @AppStorage("YoWall_PauseOnLowPower") private var pauseOnLowPower: Bool = true
        @AppStorage("YoWall_Placement") private var placement: WallpaperPlacement = .both
        
        var shouldPause: Bool {
            let powerPause = pauseOnLowPower && powerObserver.isLowPowerModeEnabled
            return powerPause || workspaceObserver.isFullScreenAppActive || wallpaperManager.isManuallyPaused
        }
        
        var body: some View {
            ZStack {
                Color.black
                
                if (placement == .home || placement == .both),
                   let activeItem = wallpaperManager.activeWallpaper,
                   let resolved = wallpaperManager.resolveURL(for: activeItem) {
                    
                    switch activeItem.type {
                    case .video:
                        VideoWallpaperView(
                            url: resolved.url,
                            isMuted: isMuted,
                            isPaused: shouldPause
                        )
                    case .gif:
                        GifWallpaperView(
                            url: resolved.url,
                            isPaused: shouldPause
                        )
                    }
                }
            }
            .ignoresSafeArea()
        }
    }
}
