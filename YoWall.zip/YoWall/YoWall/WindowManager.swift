import Cocoa
import SwiftUI
import Combine

class WindowManager: ObservableObject {
    private var desktopWindows: [NSScreen: NSWindow] = [:]
    
    /// Prepares and displays background windows across all available screens
    func setupDesktopWindows<Content: View>(@ViewBuilder rootView: () -> Content) {
        closeDesktopWindows()
        
        for screen in NSScreen.screens {
            // Define custom window covering screen frame
            let window = NSWindow(
                contentRect: screen.frame,
                styleMask: [.borderless],
                backing: .buffered,
                defer: false
            )
            
            // Set window level directly behind desktop icons
            let desktopLevel = Int(CGWindowLevelForKey(.desktopWindow))
            window.level = NSWindow.Level(rawValue: desktopLevel)
            
            // Behavior: Appears on all spaces, stationary, excluded from window switcher
            window.collectionBehavior = [.canJoinAllSpaces, .stationary, .ignoresCycle]
            
            // Pass clicks straight through to desktop icons/Finder
            window.ignoresMouseEvents = true
            window.isOpaque = true
            window.backgroundColor = .black
            window.setFrame(screen.frame, display: true)
            
            // Embed SwiftUI wallpaper view
            let hostingView = NSHostingView(rootView: rootView())
            hostingView.frame = window.contentView?.bounds ?? screen.frame
            hostingView.autoresizingMask = [.width, .height]
            
            window.contentView = hostingView
            window.orderFront(nil)
            
            desktopWindows[screen] = window
        }
    }
    
    func closeDesktopWindows() {
        desktopWindows.values.forEach { $0.close() }
        desktopWindows.removeAll()
    }
    
    deinit {
        closeDesktopWindows()
    }
}
