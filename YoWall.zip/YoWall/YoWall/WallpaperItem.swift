import Foundation

enum WallpaperType: String, Codable {
    case video // .mp4, .mov
    case gif   // .gif
    
    static func from(url: URL) -> WallpaperType {
        let ext = url.pathExtension.lowercased()
        if ext == "gif" {
            return .gif
        }
        return .video
    }
}

struct WallpaperItem: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    let bookmarkData: Data
    let type: WallpaperType
    let addedDate: Date
    
    init(id: UUID = UUID(), name: String, bookmarkData: Data, type: WallpaperType, addedDate: Date = Date()) {
        self.id = id
        self.name = name
        self.bookmarkData = bookmarkData
        self.type = type
        self.addedDate = addedDate
    }
}
