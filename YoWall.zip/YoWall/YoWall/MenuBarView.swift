import SwiftUI

struct MenuBarView: View {
    @EnvironmentObject var manager: WallpaperManager
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Header with "Open App" button
            HStack {
                Text("YoWall Engine")
                    .font(.headline)
                Spacer()
                Button("Open App"){
                    if let delegate = NSApp.delegate as? AppDelegate {
                        delegate.openMainWindow()
                        delegate.popover?.performClose(nil)
                    }
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
            }
            
            Divider()
            
            Text("ACTIVE WALLPAPER")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.secondary)
            
            Text(manager.activeWallpaper?.name ?? "None Selected")
                .font(.subheadline)
                .lineLimit(1)
            
            Divider()
            
            // Playback Quick Controls
            HStack(spacing: 12) {
                Button(action: { manager.isManuallyPaused.toggle() }) {
                    Image(systemName: manager.isManuallyPaused ? "play.fill" : "pause.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                
                Button(action: { manager.skipNext() }) {
                    Image(systemName: "forward.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            }
            
            Divider()
            
            // Footer Settings & Quit
            HStack {
                if #available(macOS 13.0, *) {
                    SettingsLink {
                        Text("Settings")
                    }
                } else {
                    Button("Settings") {
                        NSApp.sendAction(Selector(("showSettingsWindow:")), to: nil, from: nil)
                    }
                }
                
                Spacer()
                
                // FIX: Standardized the quit process to route through AppDelegate
                Button("Quit") {
                    NSApplication.shared.terminate(nil)
                }
            }
        }
        .padding(14)
        .frame(width: 240)
    }
}
