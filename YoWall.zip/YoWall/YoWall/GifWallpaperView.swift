import SwiftUI
import Cocoa

class GifPlayerNSView: NSView {
    private var gifLayer: CALayer?
    private var currentURL: URL?
    private var totalDuration: Double = 0.0

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        wantsLayer = true
    }

    func updateGif(url: URL, isPaused: Bool, manager: WallpaperManager) {
        if currentURL == url {
            setPaused(isPaused)
            return
        }

        cleanup()
        currentURL = url

        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { return }
        let count = CGImageSourceGetCount(source)
        
        var images: [CGImage] = []
        var delays: [Double] = []
        var durationAccumulator: Double = 0.0

        for i in 0..<count {
            if let image = CGImageSourceCreateImageAtIndex(source, i, nil) {
                images.append(image)
                let delay = getFrameDuration(from: source, index: i)
                delays.append(delay)
                durationAccumulator += delay
            }
        }

        self.totalDuration = durationAccumulator
        guard !images.isEmpty else { return }

        let animation = CAKeyframeAnimation(keyPath: "contents")
        animation.calculationMode = .discrete
        animation.duration = totalDuration
        animation.repeatCount = .infinity
        animation.values = images

        var currentKeyframeTime: Double = 0.0
        var keyTimes: [NSNumber] = []
        for delay in delays {
            keyTimes.append(NSNumber(value: currentKeyframeTime / totalDuration))
            currentKeyframeTime += delay
        }
        keyTimes.append(1.0)
        animation.keyTimes = keyTimes

        let sublayer = CALayer()
        sublayer.frame = bounds
        sublayer.contentsGravity = .resizeAspectFill
        sublayer.autoresizingMask = [.layerWidthSizable, .layerHeightSizable]
        sublayer.add(animation, forKey: "gifAnimation")

        self.layer?.addSublayer(sublayer)
        self.gifLayer = sublayer
        
        // Apply initial pause state if needed
        if isPaused { setPaused(true) }
        
        manager.getCurrentTime = { [weak self] in
            guard let self = self, let layer = self.gifLayer, self.totalDuration > 0 else { return 0.0 }
            // If paused, read the timeOffset; otherwise calculate live local time
            let localTime = layer.speed == 0.0 ? layer.timeOffset : layer.convertTime(CACurrentMediaTime(), from: nil)
            return localTime.truncatingRemainder(dividingBy: self.totalDuration)
        }
    }
    
    // FIX: Safely pause Core Animation layers by calculating localized time shifts
    private func setPaused(_ paused: Bool) {
        guard let layer = gifLayer else { return }
        
        if paused && layer.speed != 0.0 {
            let pausedTime = layer.convertTime(CACurrentMediaTime(), from: nil)
            layer.speed = 0.0
            layer.timeOffset = pausedTime
        } else if !paused && layer.speed == 0.0 {
            let pausedTime = layer.timeOffset
            layer.speed = 1.0
            layer.timeOffset = 0.0
            layer.beginTime = 0.0
            let timeSincePause = layer.convertTime(CACurrentMediaTime(), from: nil) - pausedTime
            layer.beginTime = timeSincePause
        }
    }

    private func getFrameDuration(from source: CGImageSource, index: Int) -> Double {
        guard let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [String: Any],
              let gifProperties = properties[kCGImagePropertyGIFDictionary as String] as? [String: Any] else {
            return 0.1
        }
        if let delay = gifProperties[kCGImagePropertyGIFUnclampedDelayTime as String] as? Double, delay > 0 { return delay }
        if let delay = gifProperties[kCGImagePropertyGIFDelayTime as String] as? Double, delay > 0 { return delay }
        return 0.1
    }

    func cleanup() {
        gifLayer?.removeAllAnimations()
        gifLayer?.removeFromSuperlayer()
        gifLayer = nil
        currentURL = nil
    }

    override func layout() {
        super.layout()
        gifLayer?.frame = bounds
    }

    deinit {
        cleanup()
    }
}

struct GifWallpaperView: NSViewRepresentable {
    let url: URL
    let isPaused: Bool
    @EnvironmentObject var manager: WallpaperManager

    func makeNSView(context: Context) -> GifPlayerNSView {
        let view = GifPlayerNSView()
        view.updateGif(url: url, isPaused: isPaused, manager: manager)
        return view
    }

    func updateNSView(_ nsView: GifPlayerNSView, context: Context) {
        nsView.updateGif(url: url, isPaused: isPaused, manager: manager)
    }
}
