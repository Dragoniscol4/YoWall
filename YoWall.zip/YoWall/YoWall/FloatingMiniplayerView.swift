import SwiftUI

struct FloatingMiniplayerView: View {
    @EnvironmentObject var manager: WallpaperManager
    
    var body: some View {
        HStack(spacing: 16) {
            // Live Status Indicator Icon
            ZStack {
                Circle()
                    .fill(Color.accentColor.opacity(0.2))
                    .frame(width: 38, height: 38)
                
                Image(systemName: manager.isManuallyPaused ? "pause.fill" : "waveform")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.accentColor)
            }
            
            // "Currently Playing" Label & Active Title
            VStack(alignment: .leading, spacing: 2) {
                Text("CURRENTLY PLAYING")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(.secondary)
                    .tracking(0.8)
                
                Text(manager.activeWallpaper?.name ?? "No Active Wallpaper")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.primary)
                    .lineLimit(1)
            }
            
            Spacer()
            
            // Floating Control Buttons
            HStack(spacing: 20) {
                Button(action: {
                    withAnimation(.spring()) {
                        manager.skipPrevious()
                    }
                }) {
                    Image(systemName: "backward.fill")
                        .font(.system(size: 13, weight: .semibold))
                }
                .buttonStyle(.plain)
                
                Button(action: {
                    withAnimation(.spring()) {
                        manager.isManuallyPaused.toggle()
                    }
                }) {
                    Image(systemName: manager.isManuallyPaused ? "play.circle.fill" : "pause.circle.fill")
                        .font(.system(size: 28, weight: .medium))
                        .foregroundColor(.accentColor)
                }
                .buttonStyle(.plain)
                
                Button(action: {
                    withAnimation(.spring()) {
                        manager.skipNext()
                    }
                }) {
                    Image(systemName: "forward.fill")
                        .font(.system(size: 13, weight: .semibold))
                }
                .buttonStyle(.plain)
            }
            .foregroundColor(.primary)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
        .thickLiquidGlassBackground() // Employs our Liquid Glass material
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.white.opacity(0.15), lineWidth: 1)
        )
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.35), radius: 16, x: 0, y: 8)
    }
}
