import SwiftUI

enum WallpaperPlacement: String, CaseIterable, Identifiable {
    case home = "Home Screen Only"
    case lock = "Locked Screen Only"
    case both = "Both"
    
    var id: String { rawValue }
}

struct SettingsView: View {
    @AppStorage("YoWall_MuteAudio") private var isMuted: Bool = true
    @AppStorage("YoWall_PauseOnLowPower") private var pauseOnLowPower: Bool = true
    @AppStorage("YoWall_Placement") private var placement: WallpaperPlacement = .both
    @AppStorage("YoWall_ShowMenuBarItem") private var showMenuBarItem: Bool = true
    @AppStorage("YoWall_ChangeOnUnlock") private var changeOnUnlock: Bool = false
    
    var body: some View {
        TabView {
            Form {
                VStack(alignment: .leading, spacing: 18) {
                    Toggle("Mute Video Wallpapers", isOn: $isMuted)
                    
                    Toggle("Stop wallpaper when Power savings is on", isOn: $pauseOnLowPower)
                    
                    Toggle("Show Menu Bar Status Icon", isOn: $showMenuBarItem)
                    
                    Divider()
                    
                    Picker("Set Live Wallpaper in:", selection: $placement) {
                        ForEach(WallpaperPlacement.allCases) { option in
                            Text(option.rawValue).tag(option)
                        }
                    }
                    .pickerStyle(.radioGroup)
                    
                    Toggle("Cycle to next wallpaper when screen unlocks", isOn: $changeOnUnlock)
                        .disabled(placement == .home)
                    
                    Divider()
                    
                    // NEW: Cache Clearing Button
                    Button(action: {
                        LockScreenManager.shared.clearCache()
                    }) {
                        Text("Clear Lock Screen Cache")
                    }
                    .help("Deletes temporary image files generated for the Lock Screen freeze-frames.")
                }
                .padding(24)
            }
            .tabItem {
                Label("General", systemImage: "gearshape")
            }
        }
        .frame(width: 450, height: 380) // Slightly taller to fit the new button
    }
}
