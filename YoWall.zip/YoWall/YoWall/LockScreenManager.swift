import Foundation
import AppKit
import AVFoundation

enum LockScreenError: LocalizedError {
    case securityAccessFailed
    case frameExtractionFailed

    var errorDescription: String? {
        switch self {
        case .securityAccessFailed:
            return "Failed to gain security-scoped access to the video file."
        case .frameExtractionFailed:
            return "Could not extract a keyframe image from the selected media."
        }
    }
}

final class LockScreenManager {
    static let shared = LockScreenManager()
    private init() {}

    private let originalWallpaperKey = "YoWall_OriginalWallpapers"

    // MARK: - Save & Restore Original Wallpapers

    private func saveOriginalWallpapersIfNeeded() {
        let workspace = NSWorkspace.shared
        var savedURLs: [String: String] = UserDefaults.standard.dictionary(forKey: originalWallpaperKey) as? [String: String] ?? [:]
        var didSaveNew = false

        for screen in NSScreen.screens {
            guard let screenNumber = screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber else { continue }
            let screenID = screenNumber.stringValue

            if savedURLs[screenID] == nil {
                if let currentURL = workspace.desktopImageURL(for: screen) {
                    if !currentURL.absoluteString.contains("yowall_frame_") {
                        savedURLs[screenID] = currentURL.absoluteString
                        didSaveNew = true
                    }
                }
            }
        }
        
        if didSaveNew {
            UserDefaults.standard.set(savedURLs, forKey: originalWallpaperKey)
        }
    }

    func restoreOriginalWallpapers() {
        guard let savedURLs = UserDefaults.standard.dictionary(forKey: originalWallpaperKey) as? [String: String] else { return }
        let workspace = NSWorkspace.shared

        for screen in NSScreen.screens {
            guard let screenNumber = screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber else { continue }
            let screenID = screenNumber.stringValue

            if let path = savedURLs[screenID] {
                // FIX: Safely handle both modern absolute strings and legacy raw file paths
                let originalURL: URL?
                if path.hasPrefix("file://") {
                    originalURL = URL(string: path)
                } else {
                    originalURL = URL(fileURLWithPath: path)
                }
                
                // FIX: Explicitly validate that the URL is non-nil and is a valid file URL before passing to workspace
                if let originalURL = originalURL, originalURL.isFileURL {
                    let currentOptions = workspace.desktopImageOptions(for: screen) ?? [:]
                    do {
                        try workspace.setDesktopImageURL(originalURL, for: screen, options: currentOptions)
                    } catch {
                        print("[YoWall] Failed to restore original wallpaper: \(error.localizedDescription)")
                    }
                }
            }
        }
    }

    // MARK: - Main Entry Point

    func applyLockScreenWallpaper(from assetURL: URL, at timeInSeconds: Double? = nil) async throws {
        saveOriginalWallpapersIfNeeded()

        let isScoped = assetURL.startAccessingSecurityScopedResource()
        defer {
            if isScoped { assetURL.stopAccessingSecurityScopedResource() }
        }

        let staticFrameURL: URL
        let ext = assetURL.pathExtension.lowercased()

        if ext == "gif" {
            staticFrameURL = try await extractGifFrame(from: assetURL, at: timeInSeconds ?? 0.0)
        } else {
            staticFrameURL = try await extractVideoFrame(from: assetURL, at: timeInSeconds)
        }

        // FIX: Ensure the generated cache file exists and is a valid file URL
        guard staticFrameURL.isFileURL, FileManager.default.fileExists(atPath: staticFrameURL.path) else {
            throw LockScreenError.frameExtractionFailed
        }

        let workspace = NSWorkspace.shared
        for screen in NSScreen.screens {
            let currentOptions = workspace.desktopImageOptions(for: screen) ?? [:]
            do {
                try workspace.setDesktopImageURL(staticFrameURL, for: screen, options: currentOptions)
            } catch {
                print("[YoWall] Failed to set desktop image for screen: \(error.localizedDescription)")
            }
        }
    }

    // MARK: - Video Frame Extraction

    private func extractVideoFrame(from videoURL: URL, at requestedTime: Double?) async throws -> URL {
        let asset = AVURLAsset(url: videoURL)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.requestedTimeToleranceBefore = .zero
        generator.requestedTimeToleranceAfter = .zero

        let seconds = requestedTime ?? 0.5
        let time = CMTime(seconds: seconds, preferredTimescale: 600)

        return try await withCheckedThrowingContinuation { continuation in
            generator.generateCGImagesAsynchronously(forTimes: [NSValue(time: time)]) { _, image, _, result, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }

                guard result == .succeeded, let cgImage = image else {
                    continuation.resume(throwing: LockScreenError.frameExtractionFailed)
                    return
                }

                do {
                    let cacheURL = try self.saveToCache(cgImage: cgImage)
                    continuation.resume(returning: cacheURL)
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    // MARK: - GIF Frame Extraction

    private func extractGifFrame(from url: URL, at requestedTime: Double) async throws -> URL {
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else {
            throw LockScreenError.frameExtractionFailed
        }

        let count = CGImageSourceGetCount(source)
        var accumulatedTime: Double = 0.0
        var targetIndex = 0

        if requestedTime > 0.0 {
            for i in 0..<count {
                targetIndex = i
                let delay = getGifFrameDuration(from: source, index: i)
                accumulatedTime += delay
                if accumulatedTime >= requestedTime {
                    break
                }
            }
        }

        guard let cgImage = CGImageSourceCreateImageAtIndex(source, targetIndex, nil) else {
            throw LockScreenError.frameExtractionFailed
        }

        return try self.saveToCache(cgImage: cgImage)
    }

    private func getGifFrameDuration(from source: CGImageSource, index: Int) -> Double {
        guard let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [String: Any],
              let gifProperties = properties[kCGImagePropertyGIFDictionary as String] as? [String: Any] else {
            return 0.1
        }
        if let delay = gifProperties[kCGImagePropertyGIFUnclampedDelayTime as String] as? Double, delay > 0 { return delay }
        if let delay = gifProperties[kCGImagePropertyGIFDelayTime as String] as? Double, delay > 0 { return delay }
        return 0.1
    }

    // MARK: - Shared Cache Writer

    private func saveToCache(cgImage: CGImage) throws -> URL {
        let nsImage = NSImage(cgImage: cgImage, size: NSSize(width: cgImage.width, height: cgImage.height))

        guard let tiffData = nsImage.tiffRepresentation,
              let bitmap = NSBitmapImageRep(data: tiffData),
              let pngData = bitmap.representation(using: .png, properties: [:]) else {
            throw LockScreenError.frameExtractionFailed
        }

        let cacheDir = try FileManager.default.url(
            for: .cachesDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )

        let fileManager = FileManager.default

        if let files = try? fileManager.contentsOfDirectory(at: cacheDir, includingPropertiesForKeys: nil) {
            for file in files where file.lastPathComponent.hasPrefix("yowall_frame_") {
                try? fileManager.removeItem(at: file)
            }
        }

        let uniqueFilename = "yowall_frame_\(UUID().uuidString).png"
        let destinationURL = cacheDir.appendingPathComponent(uniqueFilename)

        try pngData.write(to: destinationURL, options: .atomic)
        return destinationURL
    }
    
    // MARK: - Cache Management

    func clearCache() {
        do {
            let cacheDir = try FileManager.default.url(
                for: .cachesDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: false
            )
            
            let fileManager = FileManager.default
            let files = try fileManager.contentsOfDirectory(at: cacheDir, includingPropertiesForKeys: nil)
            
            for file in files where file.lastPathComponent.hasPrefix("yowall_frame_") {
                try fileManager.removeItem(at: file)
            }
            
            // Also clear out old saved wallpaper states to prevent stale non-file URI caches
            UserDefaults.standard.removeObject(forKey: originalWallpaperKey)
            print("[YoWall] Lock screen cache and history cleared successfully.")
        } catch {
            print("[YoWall] Failed to clear cache: \(error.localizedDescription)")
        }
    }
}
