import SwiftUI
import AppKit

// MARK: - Legacy Fallback for macOS 11 (Big Sur)
struct LegacyVisualEffectView: NSViewRepresentable {
    func makeNSView(context: Context) -> NSVisualEffectView {
        let view = NSVisualEffectView()
        // .hudWindow provides a beautiful dark/light adaptive translucent glass
        view.material = .hudWindow
        view.blendingMode = .behindWindow
        view.state = .active
        return view
    }
    
    func updateNSView(_ nsView: NSVisualEffectView, context: Context) {
        // No update needed for static blur
    }
}

// MARK: - View Modifier
extension View {
    /// Applies a frosted glass background compatible down to macOS 11
    @ViewBuilder
    func liquidGlassBackground() -> some View {
        if #available(macOS 12.0, *) {
            self.background(.ultraThinMaterial)
        } else {
            self.background(LegacyVisualEffectView())
        }
    }
    
    /// Applies a slightly thicker glass for prominent elements like popovers or main cards
    @ViewBuilder
    func thickLiquidGlassBackground() -> some View {
        if #available(macOS 12.0, *) {
            self.background(.regularMaterial)
        } else {
            self.background(LegacyVisualEffectView())
        }
    }
}
