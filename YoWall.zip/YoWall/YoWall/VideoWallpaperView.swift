import SwiftUI
import Cocoa
import AVFoundation

class VideoPlayerNSView: NSView {
    private var playerLayer: AVPlayerLayer?
    private var player: AVQueuePlayer?
    private var looper: AVPlayerLooper?
    private var currentURL: URL?
    private var isAccessingScope: Bool = false

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        wantsLayer = true
    }

    func updatePlayer(url: URL, isMuted: Bool, isPaused: Bool, manager: WallpaperManager) {
        if currentURL == url, let player = player {
            player.isMuted = isMuted
            if isPaused {
                player.pause()
            } else {
                player.play()
            }
            return
        }

        cleanup()
        currentURL = url

        isAccessingScope = url.startAccessingSecurityScopedResource()

        let options = [AVURLAssetPreferPreciseDurationAndTimingKey: false]
        let asset = AVURLAsset(url: url, options: options)
        let item = AVPlayerItem(asset: asset)

        let queuePlayer = AVQueuePlayer(playerItem: item)
        queuePlayer.isMuted = isMuted
        
        self.looper = AVPlayerLooper(player: queuePlayer, templateItem: item)
        self.player = queuePlayer
        
        // NEW: Pass the time in seconds back to the manager
        manager.getCurrentTime = { [weak queuePlayer] in
            queuePlayer?.currentTime().seconds
        }

        let layer = AVPlayerLayer(player: queuePlayer)
        layer.videoGravity = .resizeAspectFill
        layer.frame = bounds
        layer.autoresizingMask = [.layerWidthSizable, .layerHeightSizable]

        self.layer?.addSublayer(layer)
        self.playerLayer = layer

        if !isPaused {
            queuePlayer.play()
        }
    }

    func cleanup() {
        player?.pause()
        playerLayer?.removeFromSuperlayer()
        looper = nil
        player = nil
        playerLayer = nil
        
        if isAccessingScope, let url = currentURL {
            url.stopAccessingSecurityScopedResource()
            isAccessingScope = false
        }
        currentURL = nil
    }

    override func layout() {
        super.layout()
        playerLayer?.frame = bounds
    }
    
    deinit {
        cleanup()
    }
}

struct VideoWallpaperView: NSViewRepresentable {
    let url: URL
    let isMuted: Bool
    let isPaused: Bool
    @EnvironmentObject var manager: WallpaperManager

    func makeNSView(context: Context) -> VideoPlayerNSView {
        let view = VideoPlayerNSView()
        view.updatePlayer(url: url, isMuted: isMuted, isPaused: isPaused, manager: manager)
        return view
    }

    func updateNSView(_ nsView: VideoPlayerNSView, context: Context) {
        nsView.updatePlayer(url: url, isMuted: isMuted, isPaused: isPaused, manager: manager)
    }
}
