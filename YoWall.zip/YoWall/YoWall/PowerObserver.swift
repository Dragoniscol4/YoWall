import Foundation
import Combine

class PowerObserver: ObservableObject {
    @Published private(set) var isLowPowerModeEnabled: Bool = ProcessInfo.processInfo.isLowPowerModeEnabled
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        // Observe Low Power Mode toggles
        NotificationCenter.default.publisher(for: NSNotification.Name.NSProcessInfoPowerStateDidChange)
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in
                let newState = ProcessInfo.processInfo.isLowPowerModeEnabled
                if self?.isLowPowerModeEnabled != newState {
                    self?.isLowPowerModeEnabled = newState
                    print("PowerState Changed - Low Power Mode: \(newState)")
                }
            }
            .store(in: &cancellables)
    }
}
